package hu.sudoku.sudoku;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SudokuApplicationTests {

	@Test
	void contextLoads() {
	}

}
